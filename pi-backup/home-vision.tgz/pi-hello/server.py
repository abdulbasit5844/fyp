#!/usr/bin/env python3
"""Tiny web server for the Pi hello page: serves index.html and live metadata at /api/info."""
import json
import os
import platform
import socket
import subprocess
import time
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

ROOT = os.path.dirname(os.path.abspath(__file__))
PORT = 8080
_prev_cpu = None


def read(path, default=""):
    try:
        with open(path) as f:
            return f.read().strip().rstrip("\x00")
    except OSError:
        return default


def cpu_percent():
    global _prev_cpu
    fields = [int(x) for x in read("/proc/stat").splitlines()[0].split()[1:]]
    idle, total = fields[3] + fields[4], sum(fields)
    pct = 0.0
    if _prev_cpu:
        d_idle, d_total = idle - _prev_cpu[0], total - _prev_cpu[1]
        if d_total:
            pct = 100.0 * (1 - d_idle / d_total)
    _prev_cpu = (idle, total)
    return round(pct, 1)


def meminfo():
    info = {}
    for line in read("/proc/meminfo").splitlines():
        k, v = line.split(":", 1)
        info[k] = int(v.split()[0]) * 1024
    return info["MemTotal"], info["MemTotal"] - info["MemAvailable"]


def os_name():
    for line in read("/etc/os-release").splitlines():
        if line.startswith("PRETTY_NAME="):
            return line.split("=", 1)[1].strip('"')
    return platform.system()


def ip_addrs():
    try:
        return subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=2).stdout.split()
    except Exception:
        return []


def info():
    st = os.statvfs("/")
    mem_total, mem_used = meminfo()
    temp = read("/sys/class/thermal/thermal_zone0/temp")
    freq = read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
    return {
        "hostname": socket.gethostname(),
        "model": read("/proc/device-tree/model", "Raspberry Pi"),
        "serial": read("/proc/device-tree/serial-number")[-8:],
        "os": os_name(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "cores": os.cpu_count(),
        "cpu_freq_mhz": int(freq) // 1000 if freq else None,
        "cpu_percent": cpu_percent(),
        "temp_c": round(int(temp) / 1000, 1) if temp else None,
        "load": os.getloadavg(),
        "mem_total": mem_total,
        "mem_used": mem_used,
        "disk_total": st.f_blocks * st.f_frsize,
        "disk_used": (st.f_blocks - st.f_bfree) * st.f_frsize,
        "uptime_s": int(float(read("/proc/uptime", "0").split()[0])),
        "ips": ip_addrs(),
        "python": platform.python_version(),
        "time": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
    }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def do_GET(self):
        if self.path.startswith("/api/info"):
            body = json.dumps(info()).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path in ("/", "/index.html"):
            super().do_GET()
        else:
            self.send_error(404)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    cpu_percent()
    ThreadingHTTPServer(("", PORT), Handler).serve_forever()
